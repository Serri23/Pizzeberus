package com.hiberus.servicios;

import com.hiberus.modelos.Usuario;


import java.util.List;

public interface ServicioUsuarios {
    List<Usuario> obtenerUsuarios();
}
